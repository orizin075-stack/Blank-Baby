#!/usr/bin/env python3
"""v943 exact local source tree, signed by NEW E8 snapshot key externally pinned."""
import argparse,base64,hashlib,json,stat
from pathlib import Path
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.exceptions import InvalidSignature
SCHEMA='tukuyo.v943.release.manifest/1';RS='tukuyo.v943.release.receipt/1'
def canon(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def h(b):return hashlib.sha256(b).hexdigest()
def verify(root,trusted_pubkey_b64):
 root=Path(root);bad=[];files={}
 if root.is_symlink() or not root.is_dir():return {'ok':False,'bad':['BAD_ROOT'],'verified_files':0}
 try:
  trust=base64.b64decode(trusted_pubkey_b64.strip(),validate=True)
  if len(trust)!=32:raise ValueError('TRUST_KEY_LENGTH')
  mbytes=(root/'META/RELEASE_MANIFEST.json').read_bytes();m=json.loads(mbytes)
  receipt=json.loads((root/'META/RELEASE_RECEIPT.json').read_bytes());p=receipt['payload']
  files=m.get('files',{})
  if m.get('schema')!=SCHEMA or m.get('version')!='v943' or type(files)!=dict or m.get('file_count')!=len(files):bad.append('MANIFEST_SCHEMA')
  if receipt['public_key']!=trusted_pubkey_b64.strip():bad.append('TRUST_ROOT_MISMATCH')
  if p.get('schema')!=RS or p.get('version')!='v943':bad.append('RECEIPT_SCHEMA')
  if p.get('manifest_sha256')!=h(mbytes):bad.append('MANIFEST_BINDING')
  for label,name in [('feature_matrix_sha256','FEATURE_MATRIX.json'),('status_sha256','STATUS_v943.json'),('source_provenance_sha256','META/PROVENANCE_SOURCE.json'),('research_layer_index_sha256','RESEARCH_LAYER_INDEX.json')]:
   if p.get(label)!=h((root/name).read_bytes()):bad.append('SOURCE_BINDING:'+label)
  if p.get('parent_v941_sha256')!=m.get('parent_v941_sha256'):bad.append('PARENT_SHA_BINDING')
  if p.get('trust_epoch')!='E8_FRESH_SNAPSHOT_NOT_BRIDGE':bad.append('TRUST_CLAIM_BOUNDARY')
  try:Ed25519PublicKey.from_public_bytes(trust).verify(base64.b64decode(receipt['signature'],validate=True),canon(p))
  except (InvalidSignature,ValueError,TypeError):bad.append('RELEASE_SIGNATURE')
  expected=set(files)|{'META/RELEASE_MANIFEST.json','META/RELEASE_RECEIPT.json'};actual=set();dirs=set()
  for path in root.rglob('*'):
   rel=path.relative_to(root).as_posix()
   if path.is_symlink():bad.append('SYMLINK:'+rel)
   if '__pycache__' in path.parts or '.pytest_cache' in path.parts or path.suffix in ('.pyc','.pyo'):bad.append('CACHE_ARTIFACT:'+rel)
   if path.is_dir():dirs.add(rel)
   elif path.is_file() or path.is_symlink():actual.add(rel)
   else:bad.append('SPECIAL_FILE:'+rel)
  for file in actual-expected:bad.append('UNEXPECTED_FILE:'+file)
  for file in expected-actual:bad.append('MISSING_FILE:'+file)
  allowed_dirs=set()
  for name in expected:
   parent=Path(name).parent
   while parent!=Path('.'):
    allowed_dirs.add(parent.as_posix());parent=parent.parent
  for d in dirs-allowed_dirs:bad.append('UNEXPECTED_DIR:'+d)
  for name,digest in files.items():
   path=Path(name)
   if path.as_posix()!=name or path.is_absolute() or '..' in path.parts or ':' in name or '\\' in name or not isinstance(digest,str) or len(digest)!=64:
    bad.append('BAD_MANIFEST_ENTRY:'+name);continue
   f=root/name
   if f.is_file() and not f.is_symlink() and h(f.read_bytes())!=digest:bad.append('FILE_HASH:'+name)
 except (OSError,ValueError,TypeError,KeyError) as ex:bad.append('MALFORMED:'+type(ex).__name__)
 return {'ok':not bad,'bad':sorted(set(bad)),'verified_files':len(files)}
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('root',nargs='?',default='.');a.add_argument('--trusted-pubkey-file',required=True);x=a.parse_args()
 try:key=Path(x.trusted_pubkey_file).read_text().strip();r=verify(x.root,key)
 except (OSError,ValueError) as e:r={'ok':False,'bad':['INVALID_EXTERNAL_TRUST:'+str(e)],'verified_files':0}
 print(json.dumps(r,sort_keys=True,ensure_ascii=False));raise SystemExit(0 if r['ok'] else 1)
