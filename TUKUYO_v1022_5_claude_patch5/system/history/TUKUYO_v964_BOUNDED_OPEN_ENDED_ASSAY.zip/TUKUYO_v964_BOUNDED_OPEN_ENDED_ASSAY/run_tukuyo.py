#!/usr/bin/env python3
"""TUKUYO v941 all-available-module CLI; requires Python 3.10+.

Use --data to choose a permanent data root OUTSIDE the signed distribution.
No unrestricted language model or unattended auto-promotion is implemented.
"""
from __future__ import annotations
import os
from pathlib import Path
import argparse,hashlib,json,sys,uuid

# v944-v947 bounded science route
sys.path.insert(0,str(Path(__file__).resolve().parent/'src'))
from tukuyo_v944.gap import search_evidence as v944_search, classify as v944_classify
from tukuyo_v945.primitive import propose as v945_propose
from tukuyo_v953.multigen import evolve as v953_evolve
from datetime import datetime,timezone
sys.path.insert(0,str(Path(__file__).resolve().parent/'src'))
from tukuyo_v957.bootstrap import mounted,verify_origins
from tukuyo_v939.integrated import full_status,run_lab,audit_lab,replay_v935
from tukuyo_v943 import epistemic as ep

ROOT=Path(__file__).resolve().parent

def v955_full_status(api,data,migration_trust=None):
    s=full_status(api,data)
    from tukuyo_v955.semantic_guard import installed,check_builtin_semantics,audit_migration,_state_path
    sem=api['organism'].s838;chk=check_builtin_semantics(sem)
    guard={'runtime_guard_installed':installed(sem),'builtin_spec_ok':chk['ok'],'builtin_spec_sha256':chk['spec_sha256']}
    if migration_trust:
        try:guard['migration']=audit_migration(data,api,migration_trust)
        except Exception as e:guard['migration']={'ok':False,'error':type(e).__name__+':'+str(e)}
    else:
        guard['migration']={'ok':None,'status':'EXTERNAL_MIGRATION_TRUST_NOT_SUPPLIED','state_present':_state_path(data).is_file()}
    s['version']='v955';s['semantic_guard_v955']=guard;s['capability_retention_v955']='FROZEN_MULTI_DOMAIN_RETENTION_GATE'
    s['ok']=bool(s.get('ok',True) and guard['runtime_guard_installed'] and guard['builtin_spec_ok'] and (not migration_trust or guard['migration'].get('ok',False)))
    return s

def output(obj):print(json.dumps(obj,ensure_ascii=False,sort_keys=True,indent=2,default=str))

def _require_live(data):
    if not (data/'state/integration_state.json').is_file():
        raise FileNotFoundError('NO_INDIVIDUAL: run init first')

def chat(api,data,trust=None,migration_trust=None):
    br=api['bridge'];_require_live(data);v955_full_status(api,data,migration_trust)
    print('TUKUYO v955: hardened semantic guard + bounded autonomous research. /help for commands. Free chat LLM not installed.')
    while True:
        try:raw=input('あなた > ').strip()
        except (KeyboardInterrupt,EOFError):print('\n終了');return
        if not raw:continue
        if raw in ('/quit','/exit'):return
        try:
            if raw=='/help':answer='/status /tick N /eval EXPR /exit. Additional modules: run "python run_tukuyo.py lab" in another shell.'
            elif raw=='/status':
                s=v955_full_status(api,data,migration_trust);answer=f"tick {s['organism']['runtime_tick']}, energy {s['organism']['energy']}; guarded={s['full_integration']['v846_1_guard']['ok']}"
            elif raw.startswith('/tick '):
                s=br.tick(api,data,int(raw[6:].strip()));answer=f"tick {s['organism']['runtime_tick']}; energy={s['organism']['energy']}"
            elif raw.startswith('/eval '):answer=json.dumps(br.evaluate(api,data,raw[6:].strip()),ensure_ascii=False)
            elif raw.startswith('/'):
                print('Unknown command; use /help');continue
            else:
                s=full_status(api,data)
                if raw in ('こんにちは','おはよう','こんばんは'):answer=f'{raw}。現在の稼働tickは{s["organism"]["runtime_tick"]}です。'
                else:answer='入力を記録しました。自由会話LLMは未接続で、現在は限定的な意味処理を利用します。'
            print('TUKUYO > '+answer)
            br.write_chat_log(data,raw,answer)
        except Exception as e:print('ERROR',type(e).__name__+':'+str(e))

def parser():
    p=argparse.ArgumentParser(description='TUKUYO v964 bounded open-ended research/evolution assay')
    p.add_argument('--data',type=Path,default=(ROOT.parent/'TUKUYO_v941_DATA'))
    p.add_argument('--ep-trust-dir',type=Path,help='External pinned local/observer/evaluator/authority public keys. Required after epistemic init.')
    p.add_argument('--cap-trust-dir',type=Path,help='External pinned capability authority key. Required to resolve learned legacy capabilities.')
    p.add_argument('--semantic-migration-trust-file',type=Path,help='External v955 Semantic Migration Authority public key. Used for signed guard migration/audit.')
    p.add_argument('--blind-gap-trust-file',type=Path,help='External v956 Blind Gap Challenge Authority public key.')
    p.add_argument('--primitive-evaluator-trust-file',type=Path,help='External v958 evaluator public key.')
    p.add_argument('--primitive-promotion-trust-file',type=Path,help='External v958 promotion authority public key.')
    sub=p.add_subparsers(dest='cmd',required=True)
    sub.add_parser('verify-origins')
    sub.add_parser('layers')
    sub.add_parser('archive-list')
    x=sub.add_parser('archive-show');x.add_argument('version')
    sub.add_parser('replay-v935',help='Fresh isolated replay of the historical v935 synthetic tests')
    i=sub.add_parser('init');i.add_argument('--individual-id',default='TUKUYO-v939-001')
    sub.add_parser('status');sub.add_parser('audit');sub.add_parser('chat')
    t=sub.add_parser('tick');t.add_argument('count',type=int)
    e=sub.add_parser('eval');e.add_argument('query')
    t=sub.add_parser('teach');t.add_argument('evidence',type=Path);t.add_argument('--apply',action='store_true')
    r=sub.add_parser('research');r.add_argument('--task',choices=('v935_reference','coupled_product','difference_shift'),default='coupled_product');r.add_argument('--seed',type=int,default=93601)
    d=sub.add_parser('diagnose');d.add_argument('queries',nargs='+');d.add_argument('--task',choices=('v935_reference','coupled_product','difference_shift'),default='v935_reference')
    l=sub.add_parser('lab',help='Run every available historical runtime module in a separate lab directory; never mutate the live individual');l.add_argument('--out',type=Path);l.add_argument('--skip-research',action='store_true')
    l=sub.add_parser('lab-audit');l.add_argument('path',type=Path)
    ei=sub.add_parser('ep-init');ei.add_argument('--pin-out',type=Path,required=True)
    ei=sub.add_parser('ep-import');ei.add_argument('surface')
    ei=sub.add_parser('ep-challenge');ei.add_argument('surface');ei.add_argument('contradiction_json',type=Path)
    ei=sub.add_parser('ep-observe');ei.add_argument('surface');ei.add_argument('signed_observation',type=Path)
    ei=sub.add_parser('ep-options');ei.add_argument('surface')
    ei=sub.add_parser('ep-revise');ei.add_argument('surface');ei.add_argument('evaluator_receipt',type=Path);ei.add_argument('authority_receipt',type=Path)
    sub.add_parser('ep-status');sub.add_parser('ep-audit')
    sd=sub.add_parser('science-demo');sd.add_argument('--rows',type=int,default=36)
    sub.add_parser('meta-demo')
    sub.add_parser('meta-generalization-demo')
    sub.add_parser('retention-demo')
    sub.add_parser('semantic-migrate')
    sub.add_parser('semantic-guard-status')
    bg=sub.add_parser('blind-gap-classify');bg.add_argument('commitment',type=Path);bg.add_argument('reveal',type=Path);bg.add_argument('--budget',type=int)
    np=sub.add_parser('novel-primitive-propose');np.add_argument('commitment',type=Path);np.add_argument('reveal',type=Path)
    pi=sub.add_parser('primitive-install');pi.add_argument('proposal',type=Path);pi.add_argument('evaluator_receipt',type=Path);pi.add_argument('promotion_receipt',type=Path)
    pe=sub.add_parser('primitive-eval');pe.add_argument('candidate_sha256');pe.add_argument('a',type=int);pe.add_argument('b',type=int)
    sub.add_parser('primitive-registry-audit')
    sub.add_parser('open-ended-assay')
    cr=sub.add_parser('cap-request');cr.add_argument('surface');cr.add_argument('--out',type=Path,required=True)
    ci=sub.add_parser('cap-install');ci.add_argument('request',type=Path);ci.add_argument('receipt',type=Path)
    social=sub.add_parser('social');ss=social.add_subparsers(dest='social_cmd',required=True)
    x=ss.add_parser('send');x.add_argument('recipient');x.add_argument('--message',default='');x.add_argument('--out',required=True,type=Path)
    x=ss.add_parser('receive');x.add_argument('packet',type=Path);x.add_argument('--ack-out',required=True,type=Path)
    x=ss.add_parser('ack');x.add_argument('packet',type=Path);x.add_argument('ack',type=Path)
    x=ss.add_parser('peer');x.add_argument('peer');x.add_argument('--private',action='store_true')
    return p

def main(argv=None):
    args=parser().parse_args(argv)
    data=args.data.resolve()
    try:
        if args.cmd in ('archive-list','archive-show'):
            idx=json.loads((ROOT/'RESEARCH_LAYER_INDEX.json').read_text(encoding='utf-8'))
            if args.cmd=='archive-list':output({'ok':True,'release_count':idx['release_count'],'versions':[x['version'] for x in idx['records']],'execution_mode':'ARCHIVAL_ISOLATED'});return 0
            record=next((x for x in idx['records'] if x['version']==args.version),None)
            if record is None:output({'ok':False,'error':'UNKNOWN_VERSION'});return 1
            archive=ROOT/record['archive']
            got=hashlib.sha256(archive.read_bytes()).hexdigest()
            if got!=record['sha256']:output({'ok':False,'error':'ARCHIVE_HASH_MISMATCH'});return 1
            output({'ok':True,'record':record});return 0
        if args.cmd=='verify-origins':output({'ok':True,'origins':verify_origins()});return 0
        if args.cap_trust_dir: os.environ['TUKUYO_CAP_TRUST_DIR']=str(args.cap_trust_dir.resolve())
        else: os.environ.pop('TUKUYO_CAP_TRUST_DIR',None)
        with mounted() as api:
            bridge=api['bridge']
            if args.ep_trust_dir and not ep.roots(data).exists() and args.cmd!='ep-init':raise ValueError('EP_STATE_MISSING_WITH_EXTERNAL_PIN')
            if ep.roots(data).exists() and args.cmd!='ep-init':
                if not args.ep_trust_dir:raise ValueError('EP_EXTERNAL_TRUST_DIR_REQUIRED')
                ep.audit(data,args.ep_trust_dir)
                native_evaluate=bridge.evaluate
                bridge.evaluate=lambda local_api,local_data,q: ep.gated_evaluate(local_data,args.ep_trust_dir,q,lambda:native_evaluate(local_api,local_data,q))
            if args.cmd=='replay-v935':output(replay_v935(api));return 0
            if args.cmd=='layers':
                output({'ok':True,'loaded':sorted(x for x in api if x in ('social','organism','research','learner','guard','society','cluster','lineage','ecology','evolution')),
                        'v846_1_guard_installed':api['guard']._INSTALLED,
                        'auto_promotion':False,'external_evaluator':False,
                        'v935_audit_history':'PRESERVED_ARCHIVE_ONLY'})
                return 0
            if args.cmd=='init':
                res=bridge.init(api,data,args.individual_id)
                if args.semantic_migration_trust_file:
                    from tukuyo_v955.semantic_guard import migrate,_state_path
                    if not _state_path(data).is_file():migrate(data,api,args.semantic_migration_trust_file)
                res=v955_full_status(api,data,args.semantic_migration_trust_file)
            elif args.cmd=='ep-init':
                _require_live(data)
                res=ep.init(data,args.pin_out)
            elif args.cmd in ('ep-import','ep-challenge','ep-observe','ep-options','ep-revise','ep-status','ep-audit'):
                _require_live(data)
                if not args.ep_trust_dir:raise ValueError('EP_EXTERNAL_TRUST_DIR_REQUIRED')
                if args.cmd=='ep-import':res=ep.import_native(data,args.ep_trust_dir,args.surface)
                elif args.cmd=='ep-challenge':res=ep.challenge(data,args.ep_trust_dir,args.surface,json.loads(args.contradiction_json.read_text(encoding='utf-8')))
                elif args.cmd=='ep-observe':res=ep.observation(data,args.ep_trust_dir,args.surface,args.signed_observation)
                elif args.cmd=='ep-options':res={'ok':True,'options':ep.expected_receipts(data,args.ep_trust_dir,args.surface)}
                elif args.cmd=='ep-revise':res=ep.revise(data,args.ep_trust_dir,args.surface,args.evaluator_receipt,args.authority_receipt)
                elif args.cmd=='ep-status':res=ep.status(data,args.ep_trust_dir)
                else:res=ep.audit(data,args.ep_trust_dir)
            elif args.cmd=='meta-demo':
                res={'ok':True,'meta':v953_evolve(3)}
            elif args.cmd=='meta-generalization-demo':
                from tukuyo_v954.generalization import propose_generalizing
                res={'ok':True,'meta_generalization':propose_generalizing()}
            elif args.cmd=='retention-demo':
                from tukuyo_v955.retention import demo
                res={'ok':True,'retention':demo()}
            elif args.cmd=='semantic-migrate':
                from tukuyo_v955.semantic_guard import migrate
                _require_live(data)
                if not args.semantic_migration_trust_file:raise ValueError('SEMANTIC_MIGRATION_TRUST_FILE_REQUIRED')
                res=migrate(data,api,args.semantic_migration_trust_file)
            elif args.cmd=='semantic-guard-status':
                from tukuyo_v955.semantic_guard import audit_migration,installed,check_builtin_semantics
                _require_live(data)
                if args.semantic_migration_trust_file:res=audit_migration(data,api,args.semantic_migration_trust_file)
                else:
                    s838=api['organism'].s838;chk=check_builtin_semantics(s838);res={'ok':bool(installed(s838) and chk['ok']),'status':'RUNTIME_GUARD_ACTIVE_NO_MIGRATION_AUDIT','guard_installed':installed(s838),'builtin_spec':chk}
            elif args.cmd=='blind-gap-classify':
                from tukuyo_v956.blind_gap import classify_committed
                if not args.blind_gap_trust_file:raise ValueError('BLIND_GAP_TRUST_FILE_REQUIRED')
                res=classify_committed(args.commitment,args.reveal,args.blind_gap_trust_file,args.budget)
            elif args.cmd=='novel-primitive-propose':
                from tukuyo_v956.blind_gap import classify_committed,verify_reveal
                from tukuyo_v957.novel_primitive import propose
                if not args.blind_gap_trust_file:raise ValueError('BLIND_GAP_TRUST_FILE_REQUIRED')
                gap=classify_committed(args.commitment,args.reveal,args.blind_gap_trust_file)
                rows=verify_reveal(args.commitment,args.reveal,args.blind_gap_trust_file)['rows']
                res={'ok':True,'gap':gap,'proposal':propose(rows,gap)}
            elif args.cmd=='primitive-install':
                from tukuyo_v958.promotion import install
                if not args.primitive_evaluator_trust_file or not args.primitive_promotion_trust_file:raise ValueError('V958_EXTERNAL_TRUST_REQUIRED')
                res={'ok':True,'entry':install(data,json.loads(args.proposal.read_text()),json.loads(args.evaluator_receipt.read_text()),json.loads(args.promotion_receipt.read_text()),args.primitive_evaluator_trust_file,args.primitive_promotion_trust_file)}
            elif args.cmd=='primitive-eval':
                from tukuyo_v958.promotion import evaluate_registry
                res=evaluate_registry(data,args.candidate_sha256,args.a,args.b)
            elif args.cmd=='primitive-registry-audit':
                from tukuyo_v958.promotion import audit_registry
                res=audit_registry(data)
            elif args.cmd=='open-ended-assay':
                from tukuyo_v964.assay import run_assay
                res=run_assay()
            elif args.cmd=='cap-request':
                from tukuyo_v954.provenance import _paths,persist_teach_bundle,load,sha_obj,verify_request
                _require_live(data)
                # request must already have been persisted by teach; choose exact matching live surface request
                reqs=[]
                for rp in (data/'capability_provenance/requests').glob('*.json'):
                    q=load(rp)
                    if q.get('surface')==args.surface:
                        verify_request(data,q);reqs.append((rp,q))
                if len(reqs)!=1:raise ValueError('CAPABILITY_REQUEST_NOT_UNIQUE')
                args.out.parent.mkdir(parents=True,exist_ok=True);args.out.write_bytes(__import__('tukuyo_v954.provenance',fromlist=['canon']).canon(reqs[0][1])+b'\n')
                res={'ok':True,'request_file':str(args.out),'request_sha256':sha_obj(reqs[0][1])}
            elif args.cmd=='cap-install':
                from tukuyo_v954.provenance import install_seal
                _require_live(data)
                if not args.cap_trust_dir:raise ValueError('CAP_EXTERNAL_TRUST_DIR_REQUIRED')
                res=install_seal(data,args.cap_trust_dir,args.request,args.receipt)
            elif args.cmd=='science-demo':
                n=max(12,min(args.rows,120));rows=[]
                for i in range(n):
                    a=i-9;b=((i*5+3)%13)-6;rows.append({'a':a,'b':b,'expected':a*b+a-b})
                ev=v944_search(rows);gap=v944_classify(rows,ev);prop=v945_propose(rows,ev) if gap['state']=='REPRESENTATION_INSUFFICIENT' else None
                res={'ok':True,'scope':'SYNTHETIC_BOUNDED_DEMO','gap':gap,'proposal':prop,'auto_promotion':False}
            elif args.cmd=='lab':
                root=(args.out.resolve() if args.out else data/'labs'/(datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+uuid.uuid4().hex[:8]))
                res=run_lab(api,root,include_research=not args.skip_research)
                res['lab_directory']=str(root)
            elif args.cmd=='lab-audit':res=audit_lab(api,args.path)
            else:
                _require_live(data)
                if args.cmd in ('status','audit'):
                    res=v955_full_status(api,data,args.semantic_migration_trust_file)
                    if ep.roots(data).exists():res['epistemic']=ep.status(data,args.ep_trust_dir)
                elif args.cmd=='tick':bridge.tick(api,data,args.count);res=v955_full_status(api,data,args.semantic_migration_trust_file)
                elif args.cmd=='eval':res=bridge.evaluate(api,data,args.query)
                elif args.cmd=='teach':res=bridge.teach(api,data,args.evidence,args.apply)
                elif args.cmd=='research':res=bridge.run_research(api,data,args.task,args.seed)
                elif args.cmd=='diagnose':res=bridge.diagnose(api,data,args.queries,args.task)
                elif args.cmd=='chat':chat(api,data,args.ep_trust_dir,args.semantic_migration_trust_file);return 0
                elif args.cmd=='social':
                    bridge._require_healthy(api,data);s=api['social'];state=data/'state'
                    if args.social_cmd=='send':
                        pkt=s.make_public_packet(state,args.recipient,public_message=args.message)
                        args.out.parent.mkdir(parents=True,exist_ok=True);args.out.write_bytes(bridge.canon(pkt)+b'\n');res={'ok':True,'packet_file':str(args.out)}
                    elif args.social_cmd=='receive':
                        pkt=json.loads(args.packet.read_text(encoding='utf-8'));ack=s.receive_packet(state,pkt)
                        args.ack_out.parent.mkdir(parents=True,exist_ok=True);args.ack_out.write_bytes(bridge.canon(ack)+b'\n');res={'ok':True,'ack_file':str(args.ack_out)}
                    elif args.social_cmd=='ack':
                        pkt=json.loads(args.packet.read_text(encoding='utf-8'));ack=json.loads(args.ack.read_text(encoding='utf-8'))
                        res={'ok':bool(s.receive_ack(state,pkt,ack))}
                    else:res=s.peer_model(state,args.peer,include_private=args.private)
                else:raise ValueError('UNKNOWN_COMMAND')
            output(res)
            return 0 if res.get('ok',True) else 1
    except Exception as exc:
        output({'ok':False,'error':type(exc).__name__+':'+str(exc)})
        return 1

if __name__=='__main__':raise SystemExit(main())
