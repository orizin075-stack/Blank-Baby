#!/usr/bin/env python3
"""TUKUYO v941 all-available-module CLI; requires Python 3.10+.

Use --data to choose a permanent data root OUTSIDE the signed distribution.
No unrestricted language model or unattended auto-promotion is implemented.
"""
from __future__ import annotations
from pathlib import Path
import argparse,hashlib,json,sys,uuid

# v944-v947 bounded science route
sys.path.insert(0,str(Path(__file__).resolve().parent/'src'))
from tukuyo_v944.gap import search_evidence as v944_search, classify as v944_classify
from tukuyo_v945.primitive import propose as v945_propose
from datetime import datetime,timezone
sys.path.insert(0,str(Path(__file__).resolve().parent/'src'))
from tukuyo_v939.bootstrap import mounted,verify_origins
from tukuyo_v939.integrated import full_status,run_lab,audit_lab,replay_v935
from tukuyo_v943 import epistemic as ep

ROOT=Path(__file__).resolve().parent

def output(obj):print(json.dumps(obj,ensure_ascii=False,sort_keys=True,indent=2,default=str))

def _require_live(data):
    if not (data/'state/integration_state.json').is_file():
        raise FileNotFoundError('NO_INDIVIDUAL: run init first')

def chat(api,data,trust=None):
    br=api['bridge'];_require_live(data);full_status(api,data)
    print('TUKUYO v941: core v837-v846.1 + shadow research v937. /help for commands. Free chat LLM not installed.')
    while True:
        try:raw=input('あなた > ').strip()
        except (KeyboardInterrupt,EOFError):print('\n終了');return
        if not raw:continue
        if raw in ('/quit','/exit'):return
        try:
            if raw=='/help':answer='/status /tick N /eval EXPR /exit. Additional modules: run "python run_tukuyo.py lab" in another shell.'
            elif raw=='/status':
                s=full_status(api,data);answer=f"tick {s['organism']['runtime_tick']}, energy {s['organism']['energy']}; guarded={s['full_integration']['v846_1_guard']['ok']}"
            elif raw.startswith('/tick '):
                s=br.tick(api,data,int(raw[6:].strip()));answer=f"tick {s['organism']['runtime_tick']}; energy={s['organism']['energy']}"
            elif raw.startswith('/eval '):answer=json.dumps(br.evaluate(api,data,raw[6:].strip()),ensure_ascii=False)
            elif raw.startswith('/'):
                print('Unknown command; use /help');continue
            else:
                s=full_status(api,data)
                if raw in ('こんにちは','おはよう','こんばんは'):answer=f'{raw}。現在の稼働tickは{s["organism"]["runtime_tick"]}です。'
                else:answer='入力を記録しました。自由会話LLMは未接続で、現在は限定的な意味処理を利用します。'
            print('TUKUYO > '+answer)
            br.write_chat_log(data,raw,answer)
        except Exception as e:print('ERROR',type(e).__name__+':'+str(e))

def parser():
    p=argparse.ArgumentParser(description='TUKUYO v941 integrated living-core + society/ecology/evolution + isolated research')
    p.add_argument('--data',type=Path,default=(ROOT.parent/'TUKUYO_v941_DATA'))
    p.add_argument('--ep-trust-dir',type=Path,help='External pinned local/observer/evaluator/authority public keys. Required after epistemic init.')
    sub=p.add_subparsers(dest='cmd',required=True)
    sub.add_parser('verify-origins')
    sub.add_parser('layers')
    sub.add_parser('archive-list')
    x=sub.add_parser('archive-show');x.add_argument('version')
    sub.add_parser('replay-v935',help='Fresh isolated replay of the historical v935 synthetic tests')
    i=sub.add_parser('init');i.add_argument('--individual-id',default='TUKUYO-v939-001')
    sub.add_parser('status');sub.add_parser('audit');sub.add_parser('chat')
    t=sub.add_parser('tick');t.add_argument('count',type=int)
    e=sub.add_parser('eval');e.add_argument('query')
    t=sub.add_parser('teach');t.add_argument('evidence',type=Path);t.add_argument('--apply',action='store_true')
    r=sub.add_parser('research');r.add_argument('--task',choices=('v935_reference','coupled_product','difference_shift'),default='coupled_product');r.add_argument('--seed',type=int,default=93601)
    d=sub.add_parser('diagnose');d.add_argument('queries',nargs='+');d.add_argument('--task',choices=('v935_reference','coupled_product','difference_shift'),default='v935_reference')
    l=sub.add_parser('lab',help='Run every available historical runtime module in a separate lab directory; never mutate the live individual');l.add_argument('--out',type=Path);l.add_argument('--skip-research',action='store_true')
    l=sub.add_parser('lab-audit');l.add_argument('path',type=Path)
    ei=sub.add_parser('ep-init');ei.add_argument('--pin-out',type=Path,required=True)
    ei=sub.add_parser('ep-import');ei.add_argument('surface')
    ei=sub.add_parser('ep-challenge');ei.add_argument('surface');ei.add_argument('contradiction_json',type=Path)
    ei=sub.add_parser('ep-observe');ei.add_argument('surface');ei.add_argument('signed_observation',type=Path)
    ei=sub.add_parser('ep-options');ei.add_argument('surface')
    ei=sub.add_parser('ep-revise');ei.add_argument('surface');ei.add_argument('evaluator_receipt',type=Path);ei.add_argument('authority_receipt',type=Path)
    sub.add_parser('ep-status');sub.add_parser('ep-audit')
    sd=sub.add_parser('science-demo');sd.add_argument('--rows',type=int,default=36)
    social=sub.add_parser('social');ss=social.add_subparsers(dest='social_cmd',required=True)
    x=ss.add_parser('send');x.add_argument('recipient');x.add_argument('--message',default='');x.add_argument('--out',required=True,type=Path)
    x=ss.add_parser('receive');x.add_argument('packet',type=Path);x.add_argument('--ack-out',required=True,type=Path)
    x=ss.add_parser('ack');x.add_argument('packet',type=Path);x.add_argument('ack',type=Path)
    x=ss.add_parser('peer');x.add_argument('peer');x.add_argument('--private',action='store_true')
    return p

def main(argv=None):
    args=parser().parse_args(argv)
    data=args.data.resolve()
    try:
        if args.cmd in ('archive-list','archive-show'):
            idx=json.loads((ROOT/'RESEARCH_LAYER_INDEX.json').read_text(encoding='utf-8'))
            if args.cmd=='archive-list':output({'ok':True,'release_count':idx['release_count'],'versions':[x['version'] for x in idx['records']],'execution_mode':'ARCHIVAL_ISOLATED'});return 0
            record=next((x for x in idx['records'] if x['version']==args.version),None)
            if record is None:output({'ok':False,'error':'UNKNOWN_VERSION'});return 1
            archive=ROOT/record['archive']
            got=hashlib.sha256(archive.read_bytes()).hexdigest()
            if got!=record['sha256']:output({'ok':False,'error':'ARCHIVE_HASH_MISMATCH'});return 1
            output({'ok':True,'record':record});return 0
        if args.cmd=='verify-origins':output({'ok':True,'origins':verify_origins()});return 0
        with mounted() as api:
            bridge=api['bridge']
            if args.ep_trust_dir and not ep.roots(data).exists() and args.cmd!='ep-init':raise ValueError('EP_STATE_MISSING_WITH_EXTERNAL_PIN')
            if ep.roots(data).exists() and args.cmd!='ep-init':
                if not args.ep_trust_dir:raise ValueError('EP_EXTERNAL_TRUST_DIR_REQUIRED')
                ep.audit(data,args.ep_trust_dir)
                native_evaluate=bridge.evaluate
                bridge.evaluate=lambda local_api,local_data,q: ep.gated_evaluate(local_data,args.ep_trust_dir,q,lambda:native_evaluate(local_api,local_data,q))
            if args.cmd=='replay-v935':output(replay_v935(api));return 0
            if args.cmd=='layers':
                output({'ok':True,'loaded':sorted(x for x in api if x in ('social','organism','research','learner','guard','society','cluster','lineage','ecology','evolution')),
                        'v846_1_guard_installed':api['guard']._INSTALLED,
                        'auto_promotion':False,'external_evaluator':False,
                        'v935_audit_history':'PRESERVED_ARCHIVE_ONLY'})
                return 0
            if args.cmd=='init':res=bridge.init(api,data,args.individual_id);res=full_status(api,data)
            elif args.cmd=='ep-init':
                _require_live(data)
                res=ep.init(data,args.pin_out)
            elif args.cmd in ('ep-import','ep-challenge','ep-observe','ep-options','ep-revise','ep-status','ep-audit'):
                _require_live(data)
                if not args.ep_trust_dir:raise ValueError('EP_EXTERNAL_TRUST_DIR_REQUIRED')
                if args.cmd=='ep-import':res=ep.import_native(data,args.ep_trust_dir,args.surface)
                elif args.cmd=='ep-challenge':res=ep.challenge(data,args.ep_trust_dir,args.surface,json.loads(args.contradiction_json.read_text(encoding='utf-8')))
                elif args.cmd=='ep-observe':res=ep.observation(data,args.ep_trust_dir,args.surface,args.signed_observation)
                elif args.cmd=='ep-options':res={'ok':True,'options':ep.expected_receipts(data,args.ep_trust_dir,args.surface)}
                elif args.cmd=='ep-revise':res=ep.revise(data,args.ep_trust_dir,args.surface,args.evaluator_receipt,args.authority_receipt)
                elif args.cmd=='ep-status':res=ep.status(data,args.ep_trust_dir)
                else:res=ep.audit(data,args.ep_trust_dir)
            elif args.cmd=='science-demo':
                n=max(12,min(args.rows,120));rows=[]
                for i in range(n):
                    a=i-9;b=((i*5+3)%13)-6;rows.append({'a':a,'b':b,'expected':a*b+a-b})
                ev=v944_search(rows);gap=v944_classify(rows,ev);prop=v945_propose(rows,ev) if gap['state']=='REPRESENTATION_INSUFFICIENT' else None
                res={'ok':True,'scope':'SYNTHETIC_BOUNDED_DEMO','gap':gap,'proposal':prop,'auto_promotion':False}
            elif args.cmd=='lab':
                root=(args.out.resolve() if args.out else data/'labs'/(datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+uuid.uuid4().hex[:8]))
                res=run_lab(api,root,include_research=not args.skip_research)
                res['lab_directory']=str(root)
            elif args.cmd=='lab-audit':res=audit_lab(api,args.path)
            else:
                _require_live(data)
                if args.cmd in ('status','audit'):
                    res=full_status(api,data)
                    if ep.roots(data).exists():res['epistemic']=ep.status(data,args.ep_trust_dir)
                elif args.cmd=='tick':bridge.tick(api,data,args.count);res=full_status(api,data)
                elif args.cmd=='eval':res=bridge.evaluate(api,data,args.query)
                elif args.cmd=='teach':res=bridge.teach(api,data,args.evidence,args.apply)
                elif args.cmd=='research':res=bridge.run_research(api,data,args.task,args.seed)
                elif args.cmd=='diagnose':res=bridge.diagnose(api,data,args.queries,args.task)
                elif args.cmd=='chat':chat(api,data,args.ep_trust_dir);return 0
                elif args.cmd=='social':
                    bridge._require_healthy(api,data);s=api['social'];state=data/'state'
                    if args.social_cmd=='send':
                        pkt=s.make_public_packet(state,args.recipient,public_message=args.message)
                        args.out.parent.mkdir(parents=True,exist_ok=True);args.out.write_bytes(bridge.canon(pkt)+b'\n');res={'ok':True,'packet_file':str(args.out)}
                    elif args.social_cmd=='receive':
                        pkt=json.loads(args.packet.read_text(encoding='utf-8'));ack=s.receive_packet(state,pkt)
                        args.ack_out.parent.mkdir(parents=True,exist_ok=True);args.ack_out.write_bytes(bridge.canon(ack)+b'\n');res={'ok':True,'ack_file':str(args.ack_out)}
                    elif args.social_cmd=='ack':
                        pkt=json.loads(args.packet.read_text(encoding='utf-8'));ack=json.loads(args.ack.read_text(encoding='utf-8'))
                        res={'ok':bool(s.receive_ack(state,pkt,ack))}
                    else:res=s.peer_model(state,args.peer,include_private=args.private)
                else:raise ValueError('UNKNOWN_COMMAND')
            output(res)
            return 0 if res.get('ok',True) else 1
    except Exception as exc:
        output({'ok':False,'error':type(exc).__name__+':'+str(exc)})
        return 1

if __name__=='__main__':raise SystemExit(main())
