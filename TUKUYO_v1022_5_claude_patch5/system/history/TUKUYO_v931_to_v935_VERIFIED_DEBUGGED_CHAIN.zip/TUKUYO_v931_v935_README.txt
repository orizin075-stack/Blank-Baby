TUKUYO v931-v935 VERIFIED DEBUGGED CHAIN

Contents:
- v931 parent audit-repair ZIP
- v932 Evidence Integrity Repair
- v933 Counterexample-Derived Interaction Grammar
- v934 Active Boundary Calibration
- v935 Hardened Debug Checkpoint
- external trusted public keys for E5 and E6
- fresh validation, deep adversarial audit, chain index, and trust-bridge status

Important: E5->E6 cryptographic rotation bridge is NOT proven. The exact v931 parent ZIP hash is bound by v932. Real H3/H4 semantic evaluation, independent third-party receipt, and the 30-day two-fork run remain pending.
