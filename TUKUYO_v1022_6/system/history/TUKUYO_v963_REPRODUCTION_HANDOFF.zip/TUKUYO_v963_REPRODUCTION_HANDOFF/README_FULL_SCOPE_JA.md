# TUKUYO v941 — Flat runtime + archived full available lineage

## Directly executable after extraction

- `src/legacy/tukuyo_v837` — individual, autobiographical memory and signed state.
- `tukuyo_v838`, `v840`, `v841`, `v842`, `v843`, `v844`, `v845`, `v846`, `v846_1` — finite semantic teaching, social/other-agent, signed cluster, lineage, ecology, bounded genome evolution, runtime guard.
- `src/research/tukuyo_research_v936`, `v937` — synthetic bounded research, signed external-evaluator receipt FORMAT. No independent evaluator ran in this release.
- `src/tukuyo_v938`, `src/tukuyo_v939` — real bridges and comprehensive lab audit. All modules import directly from `src/` without recursive ZIP extraction.
- `research_layers/releases/` — EXACT 45 original research packages v891..v935. Their extracted source and evidence are in `research_layers/sources/`. Not live auto-promoted.
- `history/` — byte-exact v931..v935 official signed chain used for sandboxed v935 replay.

## Start (Python 3.10+, Linux, macOS, or Windows WSL2)

```bash
cd TUKUYO_v941_COMPLETE_FLAT_RUNTIME
python3 -m pip install -r requirements.txt
python3 -B run_selftest.py
python3 -B run_tukuyo.py layers
python3 -B run_tukuyo.py --data ../TUKUYO_v941_DATA init
python3 -B run_tukuyo.py --data ../TUKUYO_v941_DATA chat
```

Research and integration:

```bash
python3 -B run_tukuyo.py --data ../TUKUYO_v941_DATA lab
python3 -B run_tukuyo.py --data ../TUKUYO_v941_DATA research --task coupled_product
python3 -B run_tukuyo.py archive-list
python3 -B run_tukuyo.py archive-show v935
python3 -B run_tukuyo.py replay-v935
```

The full available archive is a DIFFERENT larger ZIP containing this runnable tree directly (not only nested archives) plus the original v846.1 and v890–v940 distribution bundles under `ORIGINAL_HISTORY/`. `HISTORY_INDEX.json` exposes hashes.

## Explicit limitations

The v839 original full distribution bytes were not recovered in the supplied ancestry; v840 still records its expected SHA. v890 is a large recursively embedded earlier history; its older ancestors have not been independently audited here. v891–v935 comprise separate bounded/synthetic experiments; they are included and inspectable, not a single autonomous code-evolving policy. v937 is shadow-only. No unrestricted offline LLM/free dialogue, no H3/H4 canonical end-to-end verification, no independent third-party semantic receipt, no externally time-anchored 30-day continuity, and no cryptographically proven old-signing-key rotation. `v941` is locally signed with a NEW developer key; this key must be obtained and trusted separately.
