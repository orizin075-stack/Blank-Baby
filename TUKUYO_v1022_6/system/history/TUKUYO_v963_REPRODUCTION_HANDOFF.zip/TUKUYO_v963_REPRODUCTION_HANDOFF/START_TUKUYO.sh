#!/bin/sh
set -eu
cd "$(dirname "$0")"
python3 -B run_tukuyo.py verify-origins
python3 -B run_tukuyo.py --data "$(cd .. && pwd)/TUKUYO_v941_DATA" init
python3 -B run_tukuyo.py --data "$(cd .. && pwd)/TUKUYO_v941_DATA" chat
