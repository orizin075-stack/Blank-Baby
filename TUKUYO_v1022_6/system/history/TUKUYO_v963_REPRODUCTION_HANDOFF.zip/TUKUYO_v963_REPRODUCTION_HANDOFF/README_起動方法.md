# TUKUYO v941 flat complete runtime

完全に展開した v837/v838/v840–v846.1、v937、v938 bridge と v940 audit adapter を直接 import する構成。歴史的なZIPを実行のたびに展開しません。v839単独のオリジナル配布バイトは本版で未回収です。

```bash
python3 -m pip install -r requirements.txt
python3 -B run_selftest.py
python3 -B run_tukuyo.py layers
python3 -B run_tukuyo.py --data ../TUKUYO_v941_DATA init
python3 -B run_tukuyo.py --data ../TUKUYO_v941_DATA chat
python3 -B run_tukuyo.py --data ../TUKUYO_v941_DATA lab
python3 -B run_tukuyo.py replay-v935
```

表示する自由会話は簡易CLIのみ。学習は例を明示指定して `teach --apply` しない限りライブ個体へ適用されない。研究系は shadow-only。旧ZIPの署名は v941の派生コードを署名したことになりません。過去配布物は別の `TUKUYO_v941_COMPLETE_HISTORY.zip` に元のバイトで保存。
