from pathlib import Path
import os, subprocess,sys
ROOT=Path(__file__).resolve().parent
p=subprocess.run([sys.executable,'-B','-m','unittest','discover','-s','tests','-v'],cwd=ROOT,
 env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONPATH':str(ROOT/'src')})
raise SystemExit(p.returncode)
