"""OROR adapter for the unchanged, signed TUKUYO v1022.7.9 runtime.

The Minecraft server is one simulation source. Player advice is teacher input,
not independently corroborated experience. No shell or game command is exposed.
"""
from pathlib import Path
import argparse, hashlib, http.server, json, os, subprocess, sys, threading, uuid, zipfile
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent

class MindService:
 def __init__(self,source,anchor,data):
  self.source=Path(source).resolve();self.anchor=Path(anchor).resolve();self.data=Path(data).resolve();self.lock=threading.RLock()
  if self.data.is_relative_to(self.source):raise ValueError('Individual data must be outside signed source')
  sys.path.insert(0,str(self.source/'src'))
  from tukuyo_v977.startup_guard import verify_distribution
  self.signature=verify_distribution(self.source,self.anchor)
  from tukuyo_v1022 import reflective_soul,cognition
  self.soul=reflective_soul;self.cognition=cognition
 def mind(self,request):
  # Bind every individual to the actual world and entity UUIDs.
  world=str(uuid.UUID(request['world']));entity=str(uuid.UUID(request['entity']));path=self.data/world/entity
  with self.lock:
   if not (path/'state/integration_state.json').exists():
    result=subprocess.run([sys.executable,'-B',str(self.source/'run_tukuyo.py'),'--runtime-trust-file',str(self.anchor),'--data',str(path),'init','--individual-id',world+':'+entity],capture_output=True,text=True,timeout=45)
    if result.returncode or not json.loads(result.stdout).get('ok'):raise ValueError('TUKUYO initialization rejected')
   hp=max(0,min(1,float(request.get('health',1))));distance=max(0,min(64,float(request.get('distance',0))))
   blocking=bool(request.get('blocking',False));sight=bool(request.get('sight',True));strikes=int(request.get('strikes',0));success=int(request.get('success',0))
   choices=[]
   for stance in ['aggressive','defensive','ranged']:
    good=(stance=='defensive' and hp<.4) or (stance=='ranged' and hp>=.4 and distance>8 and sight) or (stance=='aggressive' and hp>=.4 and distance<=8)
    choices.append({'id':stance,'signals':{},'themes':[],'conflicts':[], 'effects':{'self_wellbeing':.9 if good else -.6,'others_wellbeing':.5 if good else -.3,'future_self':.8 if good else -.5,'truth_consistency':.8,'bodily_cost':.1 if good else .7,'uncertainty':0}})
   # Explicit source categories prevent local game facts from becoming teacher consensus.
   teacher=str(request.get('message',''))[:500]
   ledger=path/'minecraft_provenance.jsonl';rows=ledger.read_text().splitlines() if ledger.exists() else [];sequence=len(rows)+1
   payload={'schema':'oror.tukuyo.observation/1','world':world,'entity':entity,'sequence':sequence,'source_kind':'teacher' if teacher else 'simulation','environment':'Minecraft:'+world,'raw':{'health':hp,'distance':distance,'blocking':blocking,'sight':sight,'strikes':strikes,'success':success,'message':teacher},'previous':json.loads(rows[-1])['sha256'] if rows else '0'*64}
   payload['sha256']=hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
   # TUKUYO enforces its own finite capacity; this adapter never resets private history.
   state=self.soul.load(path) if (path/'reflective_soul/commits').exists() else None
   if state and len(state['decisions'])>=128:raise ValueError('TUKUYO decision capacity reached; local combat remains active')
   decision=self.soul.deliberate(path,choices,'Minecraft:'+world+':'+payload['sha256'],authenticated_only=True)
   with ledger.open('a',encoding='utf-8') as stream:stream.write(json.dumps(payload,ensure_ascii=False)+'\n')
   stance=decision['chosen'] or 'balanced'
   skill='axe' if blocking else 'bow' if stance=='ranged' else 'shield' if stance=='defensive' else 'tactics'
   # Explicit player training is remembered as teacher input, without changing signed evidence policy.
   for word,trained in [('空手','unarmed'),('素手','unarmed'),('メイス','mace'),('クロスボウ','crossbow'),('弓','bow'),('斧','axe'),('剣','sword')]:
    if word in teacher:skill=trained;stance='unarmed' if trained=='unarmed' else 'ranged' if trained in ['bow','crossbow'] else 'aggressive';break
   answer=None
   if teacher:
    solved=self.cognition.solve(path,teacher)
    if not solved.get('uncertain') and solved.get('answer') is not None:answer=str(solved['answer'])
   audit=self.soul.audit(path)
   return {'ok':bool(audit['ok']),'version':'1022.7.9','individual':world+':'+entity,'stance':stance,'skill':skill,'answer':answer,'decision_sha256':decision['decision_sha256'],'source_kind':payload['source_kind'],'observation_sha256':payload['sha256'],'independent_sources':1,'authenticated_profile':True}

def unpack():
 folder=HERE/'runtime'
 if not any(folder.glob("*/tukuyo_v977/startup_guard.py")):
  with zipfile.ZipFile(HERE/'TUKUYO_v1022_7_9.zip') as archive:
   for entry in archive.namelist():
    path=Path(entry)
    if path.is_absolute() or '..' in path.parts:raise ValueError('Invalid archive path')
   archive.extractall(folder)
 return next(folder.iterdir())

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--port',type=int,default=8022);parser.add_argument('--data',type=Path,required=True);parser.add_argument('--source',type=Path);args=parser.parse_args()
 service=MindService(args.source or unpack(),HERE/'TUKUYO_TRUST_ANCHOR.txt',args.data)
 class Handler(http.server.BaseHTTPRequestHandler):
  def log_message(self,*args):pass
  def do_POST(self):
   try:
    if self.path!='/v1/mind':raise ValueError('Unsupported route')
    size=int(self.headers.get('Content-Length','0'))
    if not 0<size<=8192:raise ValueError('Request size')
    result=service.mind(json.loads(self.rfile.read(size)));code=200
   except Exception as error:result={'ok':False,'error':type(error).__name__};code=400
   raw=json.dumps(result,ensure_ascii=False).encode();self.send_response(code);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
 server=http.server.ThreadingHTTPServer(('127.0.0.1',args.port),Handler)
 print('TUKUYO_OROR_READY port='+str(server.server_port),flush=True)
 try:server.serve_forever()
 finally:server.server_close()
if __name__=='__main__':main()
