# 会話・AI・TUKUYO v0.13.0


何も持たずにShift＋右クリックして話す相手を選択し、チャットに「話：空手を鍛えて」「調査：盾対策を調べて」等を入力します。/oror talk、/oror research、/oror follow も使用できます。明示した武器指示は即時に戦闘設定へ反映し、訓練・経験で強さが変わります。

生成AIを使うにはサーバー側で `python3 -m pip install -r integrations/local_ai/requirements.txt` と `python3 integrations/local_ai/server.py` を実行します。初回は公式Qwen3-0.6B Q8_0（約639MB、Apache-2.0）を固定リビジョン・SHA256で検証して取得します。別途必要なCPUホイールは同封AIガイドに記載します。サービスは127.0.0.1:8023にのみ接続します。外部OpenAI方式も設定できますが、以前の実API検証では残高不足の429でした。支払いや残高は変更していません。

ローカルQwenは定型応答だけでなく日本語の文章を生成します。ローカル調査はMicrosoft Minecraft Creator / Epic Fight公式READMEの取得に限定され、任意のインターネット検索・動画視聴ではありません。外部OpenAIの検索機能はAPIが利用可能な場合のみ動作します。未接続時は明示したキーワード応答に切り替わります。

全会話をワールド内oror_dialogueの個体別JSONLへ保存し、相手プレイヤーの記憶だけを検索します。NBT直近12件とは別に全記録を残し、応答用検索は末尾2MiB・関連8件まで。非同期2処理、最大128待機、保存2048件の上限を設けています。既定は3秒の会話間隔、ローカル600件/時、外部16件/時。100人分の生成を瞬時に返せる構成ではありません。

TUKUYOの署名済み原本も同封し、`python3 integrations/tukuyo/run_service.py` を別途起動すると個体ごとの記憶・技能と連携します。8022はTUKUYO、8023はQwenです。LLMの文章をサーバーコマンドとして実行しません。


CPUホイール導入例：

```sh
python3 -m pip install --extra-index-url https://abetlen.github.io/llama-cpp-python/whl/cpu -r integrations/local_ai/requirements.txt
python3 integrations/local_ai/server.py
```

生成が遅い場合はサービス起動時の --threads を調整できます。モデルは同梱していません。100人同時会話の応答遅延はモデル用ハードウェアに依存します。
