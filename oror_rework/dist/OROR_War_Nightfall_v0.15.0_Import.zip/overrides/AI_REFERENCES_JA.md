# 参考資料と再現範囲 v0.13.0

- A-bros. 作者公開の最強PVPマスター： https://note.com/a_bros/n/n165acf3c7d6d 。統合版の5段階・水着地・縦積み・横移動等を資料として確認。Javaへコードやテクスチャをコピーしたものではない。
- Weapons of Miracles 作者配布： https://www.curseforge.com/minecraft/mc-mods/weapons-of-miracles-epicfight/files/8829395 。MC1.21.1 NeoForge、Epic Fight21.17.3.1対応記載を確認。All Rights Reserved。JAR再配布せず公式ファイルIDで導入。
- PrismarineJS公式： https://github.com/PrismarineJS/node-minecraft-protocol 。通信負荷クライアント1.66.2を使用。実プレイヤーの意思決定や全MODのクライアント実装とは異なる。
- Qwen公式： https://huggingface.co/Qwen/Qwen3-0.6B-GGUF 。Q8_0、固定リビジョン23749fefcc72300e3a2ad315e1317431b06b590a、SHA256 9465e63a22add5354d9bb4b99e90117043c7124007664907259bd16d043bb031、Apache-2.0。
- llama-cpp-python公式： https://github.com/abetlen/llama-cpp-python 。CPUでローカル推論。本文は生成し、技能は固定列挙に収める。
- 添付NightfallCraft The Casket of Reveries 2.2.8.6：MC1.20.1 Forge47.4.4、215MODのmanifest/configを確認。1.21.1へ全移植したものではない。戦闘システムの着想を5オリジナル装備へ実装。

KUN・村人狂・Dream、100 Humans VS 1 AIの映像を取得して学習したとは報告しない。動画のデータセットや作者ボットとの比較試験がないため、同等以上の知能・勝率・2秒撃破を保証しない。実戦観測と保存した成否表に基づく学習のみを実装。
